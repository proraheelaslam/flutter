class Strings {
  static String news_url =
      'https://newsapi.org/v2/everything?domains=wsj.com&apiKey=6bfecaa121f14247b06404f409af2b1f';
  static String sponser_url = 'http://elxdrive.com/bidto/api/v1/get_sponsor';
}
