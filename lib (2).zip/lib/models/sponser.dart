class Sponser {
  Sponser({
    this.id,
    this.sponsorName,
    this.sponsorImage,
    this.sponsorUrl,
    this.status,
    this.iosSponsorId,
    this.addedDateFormat,
    this.updatedDateFormat,
    this.fullImage,
    this.thumbImage,
  });

  int? id;
  String? sponsorName;
  String? sponsorImage;
  String? sponsorUrl;
  String? status;
  int? iosSponsorId;
  String? addedDateFormat;
  String? updatedDateFormat;
  String? fullImage;
  String? thumbImage;

  factory Sponser.fromJson(Map<String, dynamic> json) => Sponser(
        id: json["id"],
        sponsorName: json["sponsor_name"],
        sponsorImage: json["sponsor_image"],
        sponsorUrl: json["sponsor_url"],
        status: json["status"],
        iosSponsorId: json["ios_sponsor_id"],
        addedDateFormat: json["added_date_format"],
        updatedDateFormat: json["updated_date_format"],
        fullImage: json["full_image"],
        thumbImage: json["thumb_image"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "sponsor_name": sponsorName,
        "sponsor_image": sponsorImage,
        "sponsor_url": sponsorUrl,
        "status": status,
        "ios_sponsor_id": iosSponsorId,
        "added_date_format": addedDateFormat,
        "updated_date_format": updatedDateFormat,
        "full_image": fullImage,
        "thumb_image": thumbImage,
      };
}
