import 'package:food_app/models/newsInfo.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:food_app/constants/strings.dart';
import 'package:food_app/models/sponser.dart';

class API_Manager {
  Future<NewsModel> getNews() async {
    var client = http.Client();
    var news_url = Strings.news_url;
    var newsModel;
    var response = await client.get(Uri.parse(news_url));

    if (response.statusCode == 200) {
      var jsonString = response.body;
      var jsonMap = json.decode(jsonString);
      newsModel = NewsModel.fromJson(jsonMap);
    }
    return newsModel;
  }

  Future<Sponser> getSponserLists() async {
    var client = http.Client();
    var sponser_url = Strings.sponser_url;
    var sponserModel;
    var response = await client.get(Uri.parse(sponser_url));
    if (response.statusCode == 200) {
      var jsonString = response.body;
      var jsonMap = json.decode(jsonString);
      sponserModel = NewsModel.fromJson(jsonMap);
    }
    return sponserModel;
  }
}
