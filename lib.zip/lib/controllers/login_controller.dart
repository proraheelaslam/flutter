import 'package:get/get.dart';

class LoginController extends GetxController {
  void onInit() async {
    super.onInit();
  }
}
