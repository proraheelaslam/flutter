import 'package:get/get.dart';
import 'package:shopping_app/models/news_model.dart';
import 'package:shopping_app/services/network/api.dart';

class NewsController extends GetxController {
  // var newsList = NewsModel().obs;
  RxString userName = "raheel aslam".obs;
  // final list = List<NewsModel>().obs;
  //List<NewsModel> newsList = [];
  final newsList = [].obs;

  void onInit() {
    fetchNews();
    super.onInit();
  }

  Future<void> fetchNews() async {
    var news = await Api.getNews();
  }

  void fetchProducts() async {
    var products = await Api.fetchProducts();
    if (products != null) {
      newsList.assignAll(products);
    }
  }
}
