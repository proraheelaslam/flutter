import 'package:get/get.dart';
import 'package:shopping_app/services/network/api.dart';

class ProductController extends GetxController {
  final productList = [].obs;
  RxString username = "raheel".obs;

  @override
  void onInit() {
    fetchProducts();
    super.onInit();
  }

  void fetchProducts() async {
    var products = await Api.fetchProducts();
    if (products != null) {
      productList.assignAll(products);
    }
  }
}
