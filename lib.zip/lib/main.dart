import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shopping_app/screens/login/screen_login.dart';
import 'package:shopping_app/screens/news/news_screen.dart';
import 'package:shopping_app/screens/product/product_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      home: productScreen(),
    );
  }
}
