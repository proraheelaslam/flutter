import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shopping_app/controllers/news_controller.dart';

class newsScreen extends GetView<NewsController> {
  const newsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    NewsController c = Get.put(NewsController());

    return Scaffold(
      appBar: AppBar(
        title: Text('News listing'),
      ),
      body: Column(
        children: [
          Expanded(
            flex: 8,
            child: Obx(() => ListView.builder(
                  scrollDirection: Axis.vertical,
                  padding: EdgeInsets.all(10),
                  itemCount: c.newsList.length,
                  itemBuilder: (context, index) => Card(
                    color: Colors.amber[600],
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Center(
                        child: Text(
                            '${c.newsList[index].articles![index].author}'),
                      ),
                    ),
                  ),
                )),
          ),
        ],
      ),
    );
    ;
  }
}
