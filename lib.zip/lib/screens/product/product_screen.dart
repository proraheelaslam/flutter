import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shopping_app/controllers/product_controller.dart';

class productScreen extends StatelessWidget {
  ProductController p = Get.put(ProductController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product listing'),
      ),
      body: Column(
        children: [
          Expanded(
            flex: 8,
            // child: Obx(() => ListView.builder(
            //       scrollDirection: Axis.vertical,
            //       padding: EdgeInsets.all(10),
            //       itemCount: p.productList.length,
            //       itemBuilder: (context, index) => Card(
            //         child: Padding(
            //           padding: const EdgeInsets.all(10),
            //           child: Center(
            //             child: Text('${p.productList[index].price}'),
            //           ),
            //         ),
            //       ),
            //     )

            //     ),

            child: Obx(() => ListView.builder(
                  itemCount: p.productList.length,
                  itemBuilder: (context, index) {
                    return Card(
                      child: ListTile(
                        leading:
                            Image.network('${p.productList[index].imageLink}'),
                        title: Text('${p.productList[index].price}'),
                      ),
                    );
                  },
                )),
          )
        ],
      ),
    );
    ;
  }
}
