import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_application_1/constants/strings.dart';

class API_Manager {
  void getNews() async {
    var client = http.Client();
    var news_url = Strings.news_url;
    var response = await client.get(Uri.parse(news_url));
    if (response.statusCode == 200) {
      var jsonString = response.body;
    }
  }
}
