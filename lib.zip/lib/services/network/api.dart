import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shopping_app/models/news_model.dart';
import 'package:shopping_app/models/product_model.dart';
import 'package:shopping_app/models/user_model.dart';
import 'package:shopping_app/services/network/api_url.dart';

class Api {
  static var client = http.Client();

  Future<User> login(String email, String password) async {
    final response = await http.post(
      Uri.parse(ApiUrl.loginUrl),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, String>{
        'email': email,
        'password': password,
      }),
    );
    if (response.statusCode == 201) {
      return User.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Failed to create album.');
    }
  }

  static Future<NewsModel> getNews() async {
    var client = http.Client();
    var news_url = ApiUrl.newsUrl;

    var response = await client.get(Uri.parse(news_url));
    if (response.statusCode == 200) {
      var jsonString = response.body;
      return newsModelFromJson(jsonString);
      // var jsonMap = json.decode(jsonString);
      //return NewsModel.fromJson(jsonMap);
    } else {
      throw Exception('Failed to create album.');
    }
  }

  static Future<List<Product>> fetchProducts() async {
    var response = await client.get(Uri.parse(
        'https://makeup-api.herokuapp.com/api/v1/products.json?brand=maybelline'));
    if (response.statusCode == 200) {
      return productFromJson(response.body);
    } else {
      return [];
    }
  }
}
