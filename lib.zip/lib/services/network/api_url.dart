class ApiUrl {
  static String baseUrlDev = 'https://www.google.com';
  static String baseUrlProd = 'https://www.google.com';
  static String loginUrl = 'https://www.google.com/login';
  static String registerUrl = 'https://www.google.com/signup';
  static String newsUrl =
      'https://newsapi.org/v2/everything?domains=wsj.com&apiKey=6bfecaa121f14247b06404f409af2b1f';
}
