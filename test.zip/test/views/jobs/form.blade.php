<div class="card-body">
<div class="form-group row{{ $errors->has('name') ? ' has-error' : '' }}">
    {!! Form::label('title', '', ['class' => 'col-2 col-form-label']) !!}
    <div class="col-8">
    {!! Form::text('title', isset($jobDetail) ? $jobDetail->title: null, ['class' => ' form-control',
    'id' => 'title', 'placeholder' => 'Enter title']) !!}
    {!! $errors->first('title', '<span class="help-block"><strong>:message</strong></span>') !!}
    </div>
</div>
    <div class="form-group row{{ $errors->has('customer_id') ? ' has-error' : '' }}">
        {!! Form::label('Select Customer', '', ['class' => 'col-2 col-form-label']) !!}
        <div class="col-8">
            {!! Form::select('customer_id', getAllCustomerNames(), isset($jobDetail) ? $jobDetail->customer_id: getAllCustomerNames(), ['class' => ' form-control',
            'id' => 'customer_id', 'placeholder' => 'Please select']) !!}
            {!! $errors->first('customer_id', '<span class="help-block"><strong>:message</strong></span>') !!}
        </div>
    </div>
<div class="form-group row{{ $errors->has('description') ? ' has-error' : '' }}">
    {!! Form::label('description', '', ['class' => 'col-2 col-form-label']) !!}
    <div class="col-8">
        {!! Form::textarea('description', isset($jobDetail) ? $jobDetail->title: null, ['class' => ' form-control',
        'id' => 'description', 'placeholder' => 'Enter description']) !!}
        {!! $errors->first('description', '<span class="help-block"><strong>:message</strong></span>') !!}
    </div>
</div>

<div class="form-group row{{ $errors->has('description') ? ' has-error' : '' }}">
    {!! Form::label('description', '', ['class' => 'col-2 col-form-label']) !!}
    <div class="col-8">
       <!--begin::Card-->
                                        <div class="field" align="left">
  <h3>Upload your images</h3>
  <input type="file" id="files" name="files[]" multiple />
</div>
                                        <!--end::Card-->
        <div class="card-body">
                    <div class="uppy" id="kt_uppy_3">
                        <div class="uppy-informer">
                            <div class="uppy uppy-Informer" aria-hidden="true">
                                <p role="alert">This file exceeds maximum allowed size of 977 KB </p>
                            </div>
                        </div>
                        <div class="uppy-thumbnails">

                       @if(isset($jobDetail->job_images))
                         @if(count($jobDetail->job_images) > 0)
                            @foreach($jobDetail->job_images  as $image)
                            <div class="uppy-thumbnail-container has_server_image" data-id="{{$image->id}}">
                                <div class="uppy-thumbnail"><img src="{{url('').'/uploads/jobs/'.$image->image}}"></div> <span data-id="uppy-120/png-1e-image/png-53711-1644479541196" class="uppy-remove-thumbnail"><i class="flaticon2-cancel-music"></i></span>

                            </div>

                            @endforeach
                         @endif

                       @endif
                           

                           

                        </div>
                    </div>
                </div>
    </div>
</div>

</div>

<div class="card-footer">
    <div class="row">
        <div class="col-2"></div>
        <div class="col-10">
            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
            <a href="{{url('admin/jobs')}}" class="btn btn-secondary">Cancel</a>
                </div>
    </div>
</div>


@include('admin.common.confirmation_modal')
@section('scripts')
    <script type="text/javascript">
        var delID = 0;

            $(document).ready(function() {

                    $("body").on('click','.uppy-remove-thumbnail', function() {

                         $(this).closest(".uppy-thumbnail-container").remove();
                         if ($(this).closest('.uppy-thumbnail-container').hasClass('has_server_image')) {
                               let id = $(this).closest('.uppy-thumbnail-container').attr('data-id');
                                deleteImage(id);
                         }
                    });
                   
                  if (window.File && window.FileList && window.FileReader) {
                    $("#files").on("change", function(e) {
                      var files = e.target.files,
                        filesLength = files.length;
                      for (var i = 0; i < filesLength; i++) {
                        var f = files[i]
                        var fileReader = new FileReader();
                        fileReader.onload = (function(e) {
                          var file = e.target;
                         var html = `<div class="uppy-thumbnail-container" data-id="${file.name}">
                                <div class="uppy-thumbnail"><img src="${e.target.result}"></div> <span class="uppy-thumbnail-label"></span><span data-id="uppy-en/large/editor/icon/png-2v-2v-2v-1e-image/png-1683-1579861059339" class="uppy-remove-thumbnail"><i class="flaticon2-cancel-music"></i></span>
                            </div>`;
                            $(".uppy-thumbnails").append(html);  
                          
                        });
                        fileReader.readAsDataURL(f);
                      }
                      console.log(files);
                    });
                  } else {
                   //  alert("Your browser doesn't support to File API")
                  }
                });

            function deleteImage(id){

                 let url = "{{URL::to('/')}}/admin/job/delete_image";
                 $.ajax({
                    url: url,
                    type: 'POST',  // user.destroy
                    data:{"csrf-token":"{{ csrf_token() }}", "id": id},
                    success: function(result) {
                        // Do something with the result
                        //location.reload();
                    }
            });
            }
    </script>
@endsection



